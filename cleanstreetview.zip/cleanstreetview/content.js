/**
 * CleanStreetView 2026

 */

let isolationEnabled = false;
let scrubInterval = null;

// Persist isolation across a *reload* without waiting for background messaging.
// (This avoids the "UI flashes back" moment during reload.)
const SESSION_FLAG = "__sv_iso_enabled__";

function setSessionFlag(on) {
  try {
    if (on) sessionStorage.setItem(SESSION_FLAG, "1");
    else sessionStorage.removeItem(SESSION_FLAG);
  } catch {
    // ignore
  }
}

// --- Hover suppression (optional but effective) ---
// These POI circles are often triggered by passive hover/move events.
// While isolated, we suppress pointer/mouse move events *unless* the user is actively dragging.
// This keeps Street View navigable while preventing hover-activated POIs from popping in.
let hoverSuppressInstalled = false;
let isDragging = false;

function _isOverCanvas(x, y) {
  try {
    const els = document.elementsFromPoint(x, y) || [];
    return els.some((el) => el && el.tagName === "CANVAS");
  } catch {
    return true;
  }
}

function _onPointerDown(e) {
  if (!isolationEnabled) return;
  isDragging = true;
}

function _onPointerUp(e) {
  if (!isolationEnabled) return;
  isDragging = false;
}

function _onPointerMove(e) {
  if (!isolationEnabled) return;
  if (isDragging) return;
  if (!e || typeof e.clientX !== "number") return;
  if (!_isOverCanvas(e.clientX, e.clientY)) return;
  // Stop passive hover from reaching Google Maps' overlay handlers
  e.stopImmediatePropagation();
  e.stopPropagation();
  e.preventDefault();
}

function installHoverSuppressor() {
  if (hoverSuppressInstalled) return;
  hoverSuppressInstalled = true;
  const opts = { capture: true, passive: false };
  window.addEventListener("pointerdown", _onPointerDown, opts);
  window.addEventListener("pointerup", _onPointerUp, opts);
  window.addEventListener("pointercancel", _onPointerUp, opts);
  window.addEventListener("pointermove", _onPointerMove, opts);
  // Fallbacks
  window.addEventListener("mousemove", _onPointerMove, opts);
  window.addEventListener("touchmove", _onPointerMove, opts);
}

function uninstallHoverSuppressor() {
  if (!hoverSuppressInstalled) return;
  hoverSuppressInstalled = false;
  const opts = { capture: true };
  window.removeEventListener("pointerdown", _onPointerDown, opts);
  window.removeEventListener("pointerup", _onPointerUp, opts);
  window.removeEventListener("pointercancel", _onPointerUp, opts);
  window.removeEventListener("pointermove", _onPointerMove, opts);
  window.removeEventListener("mousemove", _onPointerMove, opts);
  window.removeEventListener("touchmove", _onPointerMove, opts);
  isDragging = false;
}


// --- OPTIONAL: in-page texture "phone line cut" ---
// If POI circles are drawn directly into the same WebGL canvas as the pano,
// CSS/DOM tricks won't help. Many overlays rely on loading icon sprites via Image().
// This patch rewrites those icon URLs to a 1x1 transparent PNG data URI.

const TRANSPARENT_DATA_URI =
  "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMB/6X+oQAAAABJRU5ErkJggg==";

let iconPatchInstalled = false;
let originalImageSrcDesc = null;

function shouldBlankIconUrl(url) {
  if (!url || typeof url !== "string") return false;
  // Common hosts/paths used for POI category icons + map sprites
  return (
    url.includes("maps.gstatic.com/mapfiles/") ||
    url.includes("gstatic.com/mapfiles/") ||
    url.includes("/mapfiles/")
  );
}

function installIconPatch() {
  if (iconPatchInstalled) return;
  try {
    originalImageSrcDesc = Object.getOwnPropertyDescriptor(HTMLImageElement.prototype, "src");
    if (!originalImageSrcDesc || !originalImageSrcDesc.set) return;

    Object.defineProperty(HTMLImageElement.prototype, "src", {
      get: originalImageSrcDesc.get,
      set: function (v) {
        if (shouldBlankIconUrl(v)) {
          return originalImageSrcDesc.set.call(this, TRANSPARENT_DATA_URI);
        }
        return originalImageSrcDesc.set.call(this, v);
      }
    });

    iconPatchInstalled = true;
  } catch {
    // If this fails, we just fall back to CSS + DNR rules.
  }
}

function uninstallIconPatch() {
  if (!iconPatchInstalled) return;
  try {
    if (originalImageSrcDesc) {
      Object.defineProperty(HTMLImageElement.prototype, "src", originalImageSrcDesc);
    }
  } catch {}
  iconPatchInstalled = false;
  originalImageSrcDesc = null;
}

// --- CSS ALLOW-LIST ---
const ISO_CLASS = "sv-iso-on";
const KEEP_CLASS = "sv-iso-keep";
const STYLE_ID = "__sv_iso_style__";

function ensureIsoStyle() {
  let st = document.getElementById(STYLE_ID);
  if (!st) {
    st = document.createElement("style");
    st.id = STYLE_ID;
    document.documentElement.appendChild(st);
  }
  return st;
}

function setIsoCss(enabled) {
  const st = ensureIsoStyle();
  st.textContent = enabled
    ? `
      html, body { background: #000 !important; }

      /* Hide everything in this frame */
      html.${ISO_CLASS} * {
        visibility: hidden !important;
        opacity: 0 !important;
        pointer-events: none !important;
      }

      /* Allow-list: only elements we mark as keep */
      html.${ISO_CLASS} .${KEEP_CLASS} {
        visibility: visible !important;
        opacity: 1 !important;
        pointer-events: auto !important;
      }

      /* Keep canvas crisp */
      html.${ISO_CLASS} canvas.${KEEP_CLASS} {
        background: #000 !important;
      }
    `
    : "";
}

function clearKeepMarks() {
  document.querySelectorAll(`.${KEEP_CLASS}`).forEach((el) => el.classList.remove(KEEP_CLASS));
}

function markKeepChain(canvas) {
  clearKeepMarks();

  let el = canvas;
  while (el) {
    el.classList.add(KEEP_CLASS);
    if (el === document.body) break;

    el =
      el.parentElement ||
      (el.getRootNode() instanceof ShadowRoot ? el.getRootNode().host : null);
  }
}

// Keep a whole subtree (used for small UI elements we explicitly want visible).
function markKeepSubtree(root) {
  if (!root) return;
  root.classList.add(KEEP_CLASS);
  try {
    root.querySelectorAll('*').forEach((el) => el.classList.add(KEEP_CLASS));
  } catch {}
}

// --- CANVAS SELECTION ---
function isLargeCanvas(c) {
  const r = c.getBoundingClientRect();
  return r.width > 300 && r.height > 300;
}

function isWebGLCanvas(c) {
  try {
    return !!(c.getContext("webgl2") || c.getContext("webgl"));
  } catch {
    return false;
  }
}

/**
 * Select canvas from the render stack at the center of the viewport.
 * elementsFromPoint() returns top-most -> bottom-most.
 * We choose bottom-most LARGE canvas (prefer WebGL).
 */
function getBestCanvasFromCenterStack() {
  const cx = Math.floor(window.innerWidth / 2);
  const cy = Math.floor(window.innerHeight / 2);

  // Guard: some pages may block this, so wrap in try.
  let stack = [];
  try {
    stack = document.elementsFromPoint(cx, cy) || [];
  } catch {
    stack = [];
  }

  const canvases = stack.filter((el) => el && el.tagName === "CANVAS" && isLargeCanvas(el));
  if (!canvases.length) return null;

  // Prefer the bottom-most WebGL canvas
  for (let i = canvases.length - 1; i >= 0; i--) {
    if (isWebGLCanvas(canvases[i])) return canvases[i];
  }

  // Otherwise, bottom-most large canvas
  return canvases[canvases.length - 1];
}

/**
 * Fallback: scan all canvases and pick the biggest (prefer WebGL).
 */
function getBestCanvasByArea() {
  const canvases = Array.from(document.querySelectorAll("canvas"))
    .filter((c) => isLargeCanvas(c))
    .map((c) => ({
      c,
      r: c.getBoundingClientRect(),
      webgl: isWebGLCanvas(c),
    }));

  if (!canvases.length) return null;

  // Prefer WebGL group if any
  const webglGroup = canvases.filter((o) => o.webgl);
  const list = webglGroup.length ? webglGroup : canvases;

  list.sort((a, b) => b.r.width * b.r.height - a.r.width * a.r.height);
  return list[0].c;
}

function getBestCanvas() {
  return getBestCanvasFromCenterStack() || getBestCanvasByArea();
}

// --- THE LOGIC ---
function performScrub() {
  if (!isolationEnabled) return;

  // Attempt to prevent POI icon textures from loading (best-effort).
  installIconPatch();

  // Enable allow-list mode in this frame
  document.documentElement.classList.add(ISO_CLASS);
  setIsoCss(true);

  const canvas = getBestCanvas();

  // If this frame has no pano canvas, it stays fully hidden via CSS.
  if (!canvas) return;

  // Keep only pano canvas + minimal ancestor chain
  markKeepChain(canvas);

  // Restore the legal attribution / copyright note (kept minimal).
  const copyrightNote = document.querySelector('.EtdG7d.Hk4XGb');
  if (copyrightNote) markKeepSubtree(copyrightNote);
}

// --- LOOP ---
function startScrubbing() {
  if (scrubInterval) clearInterval(scrubInterval);
  performScrub();
  installHoverSuppressor();

  // Keep scrubbing (SPA + overlays can re-mount)
  scrubInterval = setInterval(performScrub, 120);
}

function stopScrubbing() {
  if (scrubInterval) clearInterval(scrubInterval);

  isolationEnabled = false;
  uninstallHoverSuppressor();
  uninstallIconPatch();
  clearKeepMarks();
  document.documentElement.classList.remove(ISO_CLASS);
  setIsoCss(false);
}

// --- MESSAGES ---
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "SET_ISOLATION") {
    if (msg.enabled) {
      isolationEnabled = true;
      setSessionFlag(true);
      startScrubbing();
      sendResponse({ ok: true, enabled: true });
    } else {
      stopScrubbing();
      setSessionFlag(false);
      sendResponse({ ok: true, enabled: false });
    }
    return;
  }

  if (msg.type === "GET_ISOLATION_STATE") {
    sendResponse({ ok: true, enabled: isolationEnabled });
    return;
  }

  if (msg.type === "GET_STREETVIEW_RECT") {
    const canvas = getBestCanvas();
    const rect = canvas ? canvas.getBoundingClientRect() : null;
    sendResponse({
      ok: !!rect,
      rect: rect
        ? { left: rect.left, top: rect.top, width: rect.width, height: rect.height }
        : null,
      devicePixelRatio: window.devicePixelRatio || 1,
    });
    return;
  }
});


// --- AUTO-REAPPLY AFTER REFRESH ---
// Fast-path: if we set a per-tab sessionStorage flag before reloading, we can
// immediately re-isolate at document_start without waiting for background.
try {
  if (sessionStorage.getItem(SESSION_FLAG) === "1") {
    isolationEnabled = true;
    startScrubbing();
  }
} catch {}

// Content scripts are re-injected on reload, but the user's isolation state should survive.
// We ask the service worker whether this tab was isolated, and if so we immediately re-enable.
try {
  chrome.runtime.sendMessage({ type: "HELLO_ISO" }, (resp) => {
    if (resp && resp.ok && resp.enabled) {
      isolationEnabled = true;
      startScrubbing();
    }
  });
} catch {}
