CleanStreetView 2026
===========================

An update of CleanStreetView 2020

This Chrome extension gives you a clean, distraction-free view of Google Street View.

When turned on, it removes the normal Google Maps interface so you can focus on the street view image itself — ideal for filming, screen recording, teaching, or simply exploring without clutter.

What it does

When you enable the extension, it:

Hides the Google Maps interface (menus, buttons, panels, and controls)

Removes the floating coloured place icons that appear when you move the mouse

Keeps the Street View image fully usable, so you can still:

click and drag to look around

move forward and explore normally

Keeps the copyright/attribution note visible, as required

How it works (simple explanation)

Google Street View normally shows extra on-screen elements (like place icons and interface panels).
This extension switches Street View into a “clean mode” by hiding those elements and preventing the extra place markers from loading.

How to use it

Open Google Maps Street View in your browser

Click the extension icon

The page will refresh automatically and re-open in clean mode

Click the extension again to return to the normal Google Maps view.

Good for

Screen recordings

Classroom demonstrations

Research and observation

Exploring Street View without distractions