/*
 CLEANSTREETVIEW
  v0.2026

*/

// -----------------------------
// Tab-scoped isolation state
// -----------------------------

const STORAGE_KEY = "isolatedTabIds";
let isolatedTabs = new Set(); // tabIds currently isolated
let initDone = false;

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

function storageArea() {
  // session storage is perfect: survives refreshes, resets when Chrome restarts.
  return chrome.storage?.session || chrome.storage.local;
}

async function loadIsolatedTabsFromStorage() {
  try {
    const area = storageArea();
    const data = await area.get(STORAGE_KEY);
    const arr = Array.isArray(data?.[STORAGE_KEY]) ? data[STORAGE_KEY] : [];
    return arr.filter((n) => Number.isInteger(n) && n >= 0);
  } catch {
    return [];
  }
}

async function saveIsolatedTabsToStorage() {
  try {
    const area = storageArea();
    await area.set({ [STORAGE_KEY]: Array.from(isolatedTabs) });
  } catch {
    // ignore
  }
}

async function init() {
  if (initDone) return;

  // Load persisted state.
  const persisted = await loadIsolatedTabsFromStorage();
  isolatedTabs = new Set(persisted);

  // Remove tabs that no longer exist.
  try {
    const openTabs = await chrome.tabs.query({});
    const openIds = new Set(openTabs.map((t) => t.id).filter((id) => typeof id === "number"));
    isolatedTabs = new Set(Array.from(isolatedTabs).filter((id) => openIds.has(id)));
  } catch {
    // ignore
  }

  await updatePoiSessionRules();

  // Restore badges.
  for (const tabId of isolatedTabs) {
    await setBadge(tabId, true);
  }

  await saveIsolatedTabsToStorage();
  initDone = true;
}

// -----------------------------
// POI suppression via DNR session rules
// -----------------------------

const POI_RULE_IDS = [48001, 48002, 48003, 48004, 48005, 48006, 48007];

function buildPoiRules(tabIds) {
  const transparent = chrome.runtime.getURL("transparent256.png");
  const emptyPbf = chrome.runtime.getURL("empty.pbf");

  // If there are no isolated tabs, we don't add any rules.
  if (!tabIds.length) return [];

  return [
    // Common POI/marker icon assets (best-effort; harmless if unused).
    {
      id: 48001,
      priority: 1,
      action: { type: "redirect", redirect: { url: transparent } },
      condition: {
        tabIds,
        urlFilter: "spotlight-poi",
        resourceTypes: ["image"]
      }
    },
    {
      id: 48002,
      priority: 1,
      action: { type: "redirect", redirect: { url: transparent } },
      condition: {
        tabIds,
        urlFilter: "/place_api/icons",
        resourceTypes: ["image"]
      }
    },
    {
      id: 48003,
      priority: 1,
      action: { type: "redirect", redirect: { url: transparent } },
      condition: {
        tabIds,
        urlFilter: "maps.gstatic.com/mapfiles/",
        resourceTypes: ["image"]
      }
    },
    {
      id: 48004,
      priority: 1,
      action: { type: "redirect", redirect: { url: transparent } },
      condition: {
        tabIds,
        urlFilter: "gstatic.com/mapfiles/",
        resourceTypes: ["image"]
      }
    },

    // Vector-tile overlay payloads that often carry POI/label data.
    // Redirecting to an empty PBF keeps the renderer happy without drawing overlays.
    {
      id: 48005,
      priority: 1,
      action: { type: "redirect", redirect: { url: emptyPbf } },
      condition: {
        tabIds,
        urlFilter: "/maps/vt?",
        resourceTypes: ["xmlhttprequest"]
      }
    },
    {
      id: 48006,
      priority: 1,
      action: { type: "redirect", redirect: { url: emptyPbf } },
      condition: {
        tabIds,
        urlFilter: "maps.googleapis.com/maps/vt?",
        resourceTypes: ["xmlhttprequest"]
      }
    },
    {
      id: 48007,
      priority: 1,
      action: { type: "redirect", redirect: { url: emptyPbf } },
      condition: {
        tabIds,
        urlFilter: ".google.com/vt?",
        resourceTypes: ["xmlhttprequest"]
      }
    }
  ];
}

async function updatePoiSessionRules() {
  try {
    const tabIds = Array.from(isolatedTabs);

    await chrome.declarativeNetRequest.updateSessionRules({
      removeRuleIds: POI_RULE_IDS
    });

    const rules = buildPoiRules(tabIds);
    if (rules.length) {
      await chrome.declarativeNetRequest.updateSessionRules({
        addRules: rules
      });
    }
  } catch (e) {
    console.warn("POI session-rules update failed:", e);
  }
}

// -----------------------------
// Messaging helpers
// -----------------------------

async function send(tabId, msg) {
  try {
    return await chrome.tabs.sendMessage(tabId, msg);
  } catch (e) {
    return null;
  }
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  return tab || null;
}

async function setBadge(tabId, on) {
  try {
    await chrome.action.setBadgeText({ tabId, text: on ? "ISO" : "" });
    if (on) await chrome.action.setBadgeBackgroundColor({ tabId, color: "#111111" });
  } catch {
    // ignore
  }
}

// -----------------------------
// Toggle logic
// -----------------------------

async function enableIsolation(tabId, { reload = false } = {}) {
  await init();

  isolatedTabs.add(tabId);
  await saveIsolatedTabsToStorage();
  await updatePoiSessionRules();

  // Tell the content script to isolate DOM.
  await send(tabId, { type: "SET_ISOLATION", enabled: true });
  await setBadge(tabId, true);

  // Important: POI suppression relies on DNR session redirects.
  // The already-loaded overlay payloads won't vanish until the page re-requests them.
  // So when the user *enables* isolation, we auto-reload (bypass cache) to make the
  // clean view immediate, without requiring a manual refresh.
  if (reload) {
    try {
      // Give the content script a moment to set per-tab sessionStorage flags
      // (so it can re-isolate immediately on load).
      await sleep(60);

      // Primary: hard reload.
      // In MV3 this can be Promise-based; if not, `await` is harmless.
      await chrome.tabs.reload(tabId, { bypassCache: true });
    } catch {
      // Fallback: navigate to the current URL (some Chrome builds can be picky).
      try {
        const t = await chrome.tabs.get(tabId);
        if (t?.url) await chrome.tabs.update(tabId, { url: t.url });
      } catch {
        // ignore
      }
    }
  }
}

async function disableIsolation(tabId) {
  await init();

  isolatedTabs.delete(tabId);
  await saveIsolatedTabsToStorage();
  await updatePoiSessionRules();

  await send(tabId, { type: "SET_ISOLATION", enabled: false });
  await setBadge(tabId, false);
}

async function toggleIsolation(tabId) {
  await init();

  const currently = isolatedTabs.has(tabId);
  if (currently) return disableIsolation(tabId);
  return enableIsolation(tabId, { reload: true });
}



chrome.action.onClicked.addListener(async (tab) => {
  if (!tab?.id) return;
  await toggleIsolation(tab.id);
});

chrome.commands.onCommand.addListener(async (command) => {
  const tab = await getActiveTab();
  if (!tab?.id) return;

  if (command === "toggle-isolation") await toggleIsolation(tab.id);
  if (command === "capture-isolated") await oneShotCapture(tab);
});

// If the tab reloads while isolated, keep the badge and keep the content-script isolated.
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  (async () => {
    await init();

    if (!isolatedTabs.has(tabId)) {
      await setBadge(tabId, false);
      return;
    }

    if (changeInfo.status === "loading") {
      await setBadge(tabId, true);
    }

    if (changeInfo.status === "complete") {
      await setBadge(tabId, true);
      // Nudge the content script in case the page replaced its DOM.
      await send(tabId, { type: "SET_ISOLATION", enabled: true });
    }
  })();
});

chrome.tabs.onRemoved.addListener((tabId) => {
  (async () => {
    await init();
    if (!isolatedTabs.has(tabId)) return;

    isolatedTabs.delete(tabId);
    await saveIsolatedTabsToStorage();
    await updatePoiSessionRules();
  })();
});

// Content-script handshake so it can auto-enable on refresh.
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    await init();

    if (msg?.type === "HELLO_ISO") {
      const tabId = sender?.tab?.id;
      sendResponse({ ok: true, enabled: typeof tabId === "number" && isolatedTabs.has(tabId) });
      return;
    }

    sendResponse({ ok: false });
  })();

  // Keep the message channel open for async sendResponse.
  return true;
});

// Kick init on common lifecycle hooks.
chrome.runtime.onInstalled.addListener(() => {
  init();
});

chrome.runtime.onStartup?.addListener(() => {
  init();
});
